package com.example.michael.converter;


import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    EditText dec_input;
    EditText bi_input;
    EditText hex_input;
    Button button_convert;
    TextView text_output;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        dec_input = (EditText) findViewById(R.id.dec_input);
        bi_input = (EditText) findViewById(R.id.bi_input);
        hex_input = (EditText) findViewById(R.id.hex_input);
        button_convert = (Button) findViewById(R.id.button_convert);
        text_output = (TextView) findViewById(R.id.text_output);

        button_convert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String decInput = dec_input.getText().toString();
                String biInput = bi_input.getText().toString();
                String hexInput = hex_input.getText().toString();
                try{
                    if (biInput.isEmpty() && hexInput.isEmpty()){
                        int dec = Integer.parseInt(decInput);
                        String decOutput = Integer.toString(dec);
                        String biOutput = Integer.toBinaryString(dec);
                        String hexOutput = Integer.toHexString(dec);
                        text_output.setText("DECIMAL: "+ decOutput + System.lineSeparator() +
                                "BINARY: " + biOutput + System.lineSeparator() +
                                "HEX: " + hexOutput + System.lineSeparator());
                    }
                    else if (decInput.isEmpty() && hexInput.isEmpty()){

                        try{
                            int bi = Integer.parseInt(biInput,2);
                            String decOutput = Integer.toString(bi);
                            String biOutput = Integer.toBinaryString(bi);
                            String hexOutput = Integer.toHexString(bi);
                            text_output.setText("DECIMAL: "+ decOutput + System.lineSeparator() +
                                    "BINARY: " + biOutput + System.lineSeparator() +
                                    "HEX: " + hexOutput + System.lineSeparator());
                        }
                        catch(Exception e){
                            Toast.makeText(getApplicationContext(), "Enter a new number, Binary consists of 1s and 0s!", Toast.LENGTH_LONG).show();
                        }
                    }
                    else if (decInput.isEmpty() && biInput.isEmpty()){
                        int hex = Integer.parseInt(hexInput,16);
                        String decOutput = Integer.toString(hex);
                        String biOutput = Integer.toBinaryString(hex);
                        String hexOutput = Integer.toHexString(hex);
                        text_output.setText("DECIMAL: "+ decOutput + System.lineSeparator() +
                                "BINARY: " + biOutput + System.lineSeparator() +
                                "HEX: " + hexOutput + System.lineSeparator());


                    }
                    else{
                        Toast.makeText(getApplicationContext(), "Enter only one type of number!", Toast.LENGTH_LONG).show();
                    }
                }
                catch(Exception e){
                    Toast.makeText(getApplicationContext(), "Enter a number!", Toast.LENGTH_LONG).show();
                }
            }
        });
    }
}